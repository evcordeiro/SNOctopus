<?php
echo $_REQUEST['id'];

?>