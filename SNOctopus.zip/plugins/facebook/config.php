<?php

/* Facebook config file */

define('APP_ID', '155751477815713');
define('APP_SECRET','1deb67ace222a0209d0c7783cd340821');
define('CALLBACK_URL','http://sno.wamunity.com/build/plugins/facebook/get_oauth.php');
define('PERMISSIONS','publish_stream,offline_access,manage_pages');
?>