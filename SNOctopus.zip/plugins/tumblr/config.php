<?php

/* TUMBLR config file */

define('CONSUMER_TOKEN', 'nTu0OIggfxbJXuJ1NShuB2Mr2ce7WBjXkM74rhTVRoWXCryEQ5');
define('CONSUMER_SECRET','QFsyJxnri7elEOzpzzR5dmtndQfGLYDb1FSMPkzVR5f1nkCGGE');
define('CALLBACK_URL','http://sno.wamunity.com/build/plugins/tumblr/get_oauth.php');

?>