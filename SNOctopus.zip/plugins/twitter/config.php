<?php

/**
 * @file
 * A single location to store configuration.
 */

define('CONSUMER_KEY', '87l3QJ3z5UYrGEI6njrekA');
define('CONSUMER_SECRET', '2wiFiQ79tjTBPVHC6mo6dDtIUhfPQDdfPYZTFOGg');
define('OAUTH_CALLBACK', 'http://sno.wamunity.com/build/plugins/twitter/get_oauth.php');

?>