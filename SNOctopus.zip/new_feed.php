<?php 
echo $_GET['feed'];

?>